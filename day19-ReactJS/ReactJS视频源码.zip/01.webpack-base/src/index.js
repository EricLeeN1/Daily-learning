// 1. 引包
import React from 'react';
import ReactDOM from 'react-dom';

import '@/07.class-实例方法和静态方法';

ReactDOM.render( <div>
    123
</div>,document.getElementById('app'));



