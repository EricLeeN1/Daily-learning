// 1. 引包
import React from 'react';
import ReactDOM from 'react-dom';

import BindEvent from '@/components/BindInputValue';



// 3.调用render渲染函数
ReactDOM.render( <div>
   <BindEvent></BindEvent>
</div>,document.getElementById('app'));